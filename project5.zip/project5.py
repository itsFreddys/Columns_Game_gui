from column_view import Columns
# run this module to start the game


def run_game():
    game = Columns()
    game.run()


if __name__ == '__main__':
    run_game()